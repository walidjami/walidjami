/** Class that can hold an item of any data type.
 * @author Walid Jami
 * @param <T> generic type that holds item
 */
public class SingleItemBox<T>
{

	/**
	 * Generic item of type T.
	 */
	
	private T item;

	/**
	 * Constructor of the SingleItemBox class.
	 * @param  item of generic type T
	 */
	
	public SingleItemBox(T item)
	{
		this.item = item;
	}

	/**
	 * Simple getter function that returns item.
	 * @return item instance variable
	 */
	
	public T getItem()
	{
		return this.item;
	}

}