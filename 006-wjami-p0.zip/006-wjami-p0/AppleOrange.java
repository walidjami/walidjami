/**
 * AppleOrange class that prints a fruit depending on the number argument.
 * @author Walid Jami
 */
public class AppleOrange
{

	/**
	 * Main function that checks for errors and prints specific multiples of numbers.
	 * @param args A list of string that are command line args
	 */
	public static void main(String[] args) 
	{
		int num;
		
		//first check is args length is 1
		if (args.length != 1)
		{
			System.err.println("One positive number required as a command line argument.");
			System.err.println("Example Usage: java AppleOrange [number]");
			return;
		}
		
		try
		{
			//parse.Int changes the string arg to an int
			
			num = Integer.parseInt(args[0]);
			
			//only positive ints desired
			
			if (num < 1) 
			{
				throw new Exception();
			}
		}
		
		//this is the specific error message thrown
		
		catch (Exception e) 
		{
			System.err.println("One positive number required as a command line argument.");
			System.err.println("Example Usage: java AppleOrange [number]");
			return ;
		}

		//if no error is found, this portion is completed
		
		for (int i = 1; i <= num; i++)
		{
			//first check the most specific condition and work toward broader
			
			if (i % 3 == 0 && i % 7 == 0)
			{
				System.out.print("appleorange ");
			}
			
			else if (i % 7 == 0)
			{
				System.out.print("orange ");
			}
			
			else if (i % 3 == 0)
			{
				System.out.print("apple ");
			}
			
			else
			{
				System.out.print(i + " ");
			}
		}	
	}

}