/**
 * Class represents a priority-based circular line.
 * 
 * @author Walid Jami
 * @param <T> Class uses generic type T extended by Comparable which is generic T type itself
 */

public class PriorityCircularLine<T extends Comparable<T>> implements CircularLineInterface<T>, Comparable<T> {
	
	/**
	 * T type generic array instance variable.
	 */
	private T[] array;
	/**
	 * Integer type capacity instance variable.
	 */
	private int capacity = 50;
	/**
	 * Integer type start instance variable.
	 */
	private int start = 0;
	/**
	 * Integer type end instance variable.
	 */
	private int end;
	/**
	 * Integer type size instance variable.
	 */
	private int size = 0;
	/**
	 * Integer type current instance variable used as index position.
	 */
	private T current;

	/**
	 * Constructor default for the class.
	 */
	@SuppressWarnings("unchecked")
	public PriorityCircularLine() {
		array = (T[]) new Comparable[this.capacity];
		end = capacity - 1;
	}

	/**
	 * Constructor class with a parameter.
	 * 
	 * @param capacity Capacity of the line
	 */
	@SuppressWarnings("unchecked")
	public PriorityCircularLine(int capacity) {
		array = (T[]) new Comparable[capacity];
		this.capacity = capacity;
		end = capacity - 1;
	}

	/**
	 * Doubles the capacity of the line.
	 */
	@SuppressWarnings("unchecked")
	public void doubleCapacity() {
		T[] temp = (T[]) new Comparable[capacity * 2];
		for (int i = 0; i < capacity; i++) {
			temp[i] = array[i];
		}
		array = temp;
		capacity *= 2;
		start = 0;
		end = size - 1;
	}

	/**
	 * Getter method that returns the start of line.
	 * 
	 * @return int position of the start of line
	 */
	public int getStart() {
		return start;
	}

	/**
	 * Getter method that returns the end of line.
	 * 
	 * @return int position of the end of line
	 */
	public int getEnd() {
		return end;
	}

	/**
	 * toString method that displays the line in string representation.
	 * 
	 * @return string representation of line
	 */
	@Override
	public String toString() {
		String rep = "[";
		for (int i = 0; i < capacity; i++) {
			if (size == 0)
				break;
			else if (i < size - 1)
				if (array[i] == null)
					break;
				else
					rep += array[i] + ",";
			else if (array[i] == null)
				break;
			else
				rep += array[i];
		}
		rep += "]";
		return rep;
	}

	/**
	 * Inserts new generic type element in to the line based on priority.
	 * @param newData T generic type new data element in line
	 */
	@SuppressWarnings("unchecked")
	public void insert(T newData) {
		int pos = 0, count = 0;
		if (this.isEmpty()) {
			end++;
			end = end % capacity;
			size++;
			array[0] = newData;
			// array.add(newData);
		} else if (!this.isFull()) {
			end++;
			end = end % capacity;
			for (int i = 0; i < size; i++) {
				pos = array[i].compareTo(newData);
				if (pos == 1) {
					break;
				}
				count++;
			}

			T[] temp = (T[]) new Comparable[capacity];
			temp = addAtPos(array, count, newData);
			/*
			 * for (int i=0; i<capacity; i++) { if(i==place) temp[i] = newData; else temp[i]
			 * = newData; }
			 */
			array = temp;
			size++;

			// array[count] = newData;
		} else {
			this.doubleCapacity();
			end++;
			end = end % capacity;
			for (int i = 0; i < size; i++) {
				pos = array[i].compareTo(newData);
				if (pos == 1) {
					break;
				}
				count++;
			}

			T[] temp = (T[]) new Comparable[capacity];
			temp = addAtPos(array, count, newData);
			array = temp;
			size++;

			// array[count] = newData;
		}
	}

	/**
	 * Removes the element in line that is at the end.
	 * 
	 * @throws NoElementException if line is empty
	 * @return T generic type element at end
	 */
	@SuppressWarnings("unchecked")
	public T remove() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			}
			T removed = array[this.getStart()];

			T[] temp = (T[]) new Comparable[capacity];
			for (int i = 0; i < capacity; i++) {
				if (i >= size - 1)
					temp[i] = null;
				else
					temp[i] = array[i + 1];
			}
			array = temp;

			// array.remove(this.getFront());
			start++;
			start = start % this.getCapacity();
			size -= 1;
			return removed;
			/*
			 * array.remove(this.getFront()); start++; start = start % this.getCapacity();
			 * return removed; }
			 */
		} catch (NoElementException e) {
			System.out.println("No element to process");
			return null;
		}
	}

	/**
	 * Removes all elements from the line.
	 * 
	 * @throws NoElementException if line is empty
	 */
	@SuppressWarnings("unchecked")
	public void removeAll() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				T[] temp = (T[]) new Comparable[capacity];
				for (int i = 0; i < capacity; i++) {
					temp[i] = null;
				}
				array = temp;
				start = 0;
				end = capacity - 1;
				size = 0;
			}
		} catch (NoElementException e) {
			System.out.println("No element to process");
		}
	}

	/**
	 * Getter method that returns the element at front of line.
	 * 
	 * @return T generic type element
	 */
	public T getFront() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				return array[0];
			}
		} catch (NoElementException e) {
			return null;
		}
	}

	/**
	 * Getter method that returns the element at end of line.
	 * 
	 * @return T generic type element
	 */
	public T getBack() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				return array[size - 1];
			}
		} catch (NoElementException e) {
			return null;
		}
	}

	/**
	 * Getter method that returns the capacity of line.
	 * 
	 * @return int the capacity of the line
	 */
	public int getCapacity() {
		return capacity - 1;
	}

	/**
	 * Returns the number of elements in line.
	 * 
	 * @return int number of elements in line
	 */
	public int size() {
		return size;
	}

	/**
	 * Returns boolean if line is empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return size == 0 ? true : false;
	}

	/**
	 * Returns boolean if line is full.
	 * 
	 * @return boolean
	 */
	public boolean isFull() {
		return size == capacity - 1 ? true : false;
	}

	/**
	 * Compares this T type element to parameter T type element.
	 * 
	 * @param compared T generic type element to be compared to this T type element
	 * @return int that signifies less than, equal to, greater than
	 */
	@Override
	public int compareTo(T compared) {
		current = this.getFront();
		if (this.current.compareTo(compared) == 0)
			return 0;
		else if (this.current.compareTo(compared) < 0)
			return -1;
		else
			return 1;
	}

	/**
	 * Function that adds an element at specific index of array.
	 * @param <T> Generic type T
	 * @param original The original generic array being changed
	 * @param index The index of where the new datum will be placed
	 * @param datum The new element to be placed in the line
	 * @return Returns the newly configured line
	 */
	@SuppressWarnings("unchecked")
	private static <T> T[] addAtPos(T[] original, int index, T datum) {
		T[] temp = (T[]) new Comparable[original.length];
		for (int i = 0; i < index; i++)
			temp[i] = original[i];
		temp[index] = datum;
		for (int i = index + 1; i < original.length; i++)
			temp[i] = original[i - 1];
		return temp;
	}
}
