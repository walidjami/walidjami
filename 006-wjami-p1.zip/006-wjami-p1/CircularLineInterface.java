/**
 * Interface for CircularLine.
 * @author Walid Jami
 * @param <T> Generic type interface T
 */

public interface CircularLineInterface<T> {
	/**
	 * Insert element to line.
	 * @param newData New data element to be inserted
	 */
	public void insert(T newData);
	/**
	 * Remove element from line.
	 * @return T data type to line
	 */
	public T remove();
	/**
	 * Removes all elements from line.
	 */
	public void removeAll();
	/**
	 * Getter method returning the front data element.
	 * @return T data type element at front of line
	 */
	public T getFront();
	/**
	 * Getter method returning the back data element.
	 * @return T data type element at back of line
	 */
	public T getBack();
	/**
	 * Getter method returning the capacity of the line.
	 * @return Integer type number in line
	 */
	public int getCapacity();
	/**
	 * Returns the size of the line.
	 * @return Integer type size of line
	 */
	public int size();
	/**
	 * Evaluates whether the line is empty.
	 * @return Boolean true or false
	 */
	public boolean isEmpty();
	/**
	 * Evaluates whether the line is full.
	 * @return Boolean true or false
	 */
	public boolean isFull();
}
