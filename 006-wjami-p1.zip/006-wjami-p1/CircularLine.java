/**
 * Class represents a time-based circular line.
 * 
 * @author Walid Jami
 * @param <T> CircularLine uses generic type T
 */
public class CircularLine<T> implements CircularLineInterface<T> {
	
	/**
	 * Array of generic type t instance variable.
	 */
	private T[] array;
	/**
	 * Integer type capacity instance variable.
	 */
	private int capacity = 50;
	/**
	 * Integer type start instance variable.
	 */
	private int start = 0;
	/**
	 * Integer type end instance variable.
	 */
	private int end;
	/**
	 * Integer type size instance variable.
	 */
	private int size = 0;

	/**
	 * Constructor default for the class.
	 */
	@SuppressWarnings("unchecked")
	public CircularLine() {
		array = (T[]) new Object[this.capacity];
		end = capacity - 1;
	}

	/**
	 * Constructor class with a parameter.
	 * 
	 * @param capacity The capacity of the array.
	 */
	@SuppressWarnings("unchecked")
	public CircularLine(int capacity) {
		array = (T[]) new Object[capacity];
		this.capacity = capacity;
		end = capacity - 1;
	}

	/**
	 * Doubles the capacity of the line.
	 */
	@SuppressWarnings("unchecked")
	public void doubleCapacity() {
		T[] temp = (T[]) new Object[capacity * 2];
		for (int i = 0; i < capacity; i++) {
			temp[i] = array[i];
		}
		array = temp;
		capacity *= 2;
		start = 0;
		end = size - 1;
	}

	/**
	 * Getter method that returns the start of line.
	 * 
	 * @return int position of the start of line
	 */
	public int getStart() {
		return start;
	}

	/**
	 * Getter method that returns the end of line.
	 * 
	 * @return int position of the end of line
	 */
	public int getEnd() {
		return end;
	}

	/**
	 * toString method that displays the line in string representation.
	 * 
	 * @return string representation of line
	 */
	@Override
	public String toString() {
		String rep = "[";
		for (int i = 0; i < capacity; i++) {
			if (size == 0)
				break;
			else if (i < size - 1)
				if (array[i] == null)
					break;
				else
					rep += array[i] + ",";
			else if (array[i] == null)
				break;
			else
				rep += array[i];
		}
		rep += "]";
		return rep;
	}

	/**
	 * Inserts new generic type element in to the line at end.
	 * @param newData The new data element of T type to be added to array
	 */
	@SuppressWarnings("unchecked")
	public void insert(T newData) {
		if (!this.isFull()) {

			T[] temp = (T[]) new Object[capacity];
			for (int i = 0; i < capacity; i++) {
				if (i == size)
					temp[i] = newData;
				else
					temp[i] = array[i];
			}
			array = temp;

			size += 1;
			end++;
			end = end % capacity;
			// this.getEnd()%this.getCapacity(),

			// array.add(newData);
		} else {
			// array.ensureCapacity(capacity*2);
			this.doubleCapacity();

			T[] temp = (T[]) new Object[capacity];
			for (int i = 0; i < capacity; i++) {
				if (i == size)
					temp[i] = newData;
				else
					temp[i] = array[i];
			}
			array = temp;

			size += 1;
			end++;
			end = end % capacity;
			// array.add(this.getEnd() % this.getCapacity(), newData);
		}
	}

	/**
	 * Removes the element in line that is at the end.
	 * 
	 * @throws NoElementException if line is empty
	 * @return T generic type element at end
	 */
	@SuppressWarnings("unchecked")
	public T remove() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			}
			T removed = array[this.getStart()];

			T[] temp = (T[]) new Object[capacity];
			for (int i = 0; i < capacity; i++) {
				if (i >= size - 1)
					temp[i] = null;
				else
					temp[i] = array[i + 1];
			}
			array = temp;

			// array.remove(this.getFront());
			start++;
			start = start % this.getCapacity();
			size -= 1;
			return removed;
		} catch (NoElementException e) {
			System.out.println("No element to process");
			return null;
		}
	}

	/**
	 * Removes all elements from the line.
	 * 
	 * @throws NoElementException if line is empty
	 */
	@SuppressWarnings("unchecked")
	public void removeAll() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				T[] temp = (T[]) new Object[capacity];
				for (int i = 0; i < capacity; i++) {
					temp[i] = null;
				}
				array = temp;
				start = 0;
				end = capacity - 1;
				size = 0;
			}
		} catch (NoElementException e) {
			System.out.println("No element to process");
		}
	}

	/**
	 * Getter method that returns the element at front of line.
	 * 
	 * @return T generic type element
	 */
	public T getFront() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				return array[0];
			}
		} catch (NoElementException e) {
			return null;
		}
	}

	/**
	 * Getter method that returns the element at end of line.
	 * 
	 * @return T generic type element
	 */
	public T getBack() {
		try {
			if (this.isEmpty()) {
				throw new NoElementException();
			} else {
				return array[size - 1];
			}
		} catch (NoElementException e) {
			return null;
		}
	}

	/**
	 * Getter method that returns the capacity of line.
	 * 
	 * @return int the capacity of the line
	 */
	public int getCapacity() {
		return capacity - 1;
	}

	/**
	 * Returns the number of elements in line.
	 * 
	 * @return int number of elements in line
	 */
	public int size() {
		return size;
	}

	/**
	 * Returns boolean if line is empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return size == 0 ? true : false;
	}

	/**
	 * Returns boolean if line is full.
	 * 
	 * @return boolean
	 */
	public boolean isFull() {
		return size == capacity - 1 ? true : false;
	}
}
