/**
 * User defined function when there is no element and remove is tried.
 * @author Walid Jami
 *
 */
public class NoElementException extends RuntimeException {
	/**
	 * Constructor for the class, calling super referring to RuntimeException.
	 */
	public NoElementException() {
		super();
	}

}
